# Simple-K-Nearest-Neighbor

time Spent:
-  5 min in a simple implementation using Sklearn to test
-  5 min in a crude ploting function to visualize the data and adding F Score
-  20 min in desing and researching
-  10 min implementing algorithm
-  10 min in testing and bug fix
-  10  min wasted implementing a much more complex implementation
 
case of use 

y_pred = prediction(X_train, y_train, X_test, K)

plot(X_train, y_train, X_test)
  
  
